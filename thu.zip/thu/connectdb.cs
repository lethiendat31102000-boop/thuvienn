﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace thu
{
    internal class connectdb
    {
        private string connection;

        public connectdb()
        {
            // 📌 ĐOẠN NÀY LÀ CHUỖI KẾT NỐI ĐẾN SQL SERVER CỦA BẠN:
            // - Data Source: Tên Server SQL của bạn (ví dụ: .\SQLEXPRESS hoặc (local) hoặc tên máy tính)
            // - Initial Catalog: Tên cơ sở dữ liệu bạn đã tạo (ví dụ: QuanLyThuVienDB)
            connection = connection = @"Data Source=DESKTOP-E5A7OSB\SQLEXPRESS;Initial Catalog=QuanLyThuVien;User ID=sa;Password=1;TrustServerCertificate=True;";
        }

        // Phương thức đọc dữ liệu (Dùng cho lệnh SELECT để đổ lên bảng DataGridView, Tìm kiếm...)
        public DataTable ReadData(string sql)
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connection);
            SqlCommand cmd = new SqlCommand(sql, con);

            try
            {
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                dt.Load(dr, LoadOption.OverwriteChanges);
                con.Close();
            }
            catch (Exception ex)
            {
                con.Close();
                return null;
            }
            return dt;
        }

        // Phương thức ghi/thao tác dữ liệu (Dùng cho Thêm, Sửa, Xóa - INSERT, UPDATE, DELETE)
        public int WriteData(string sql)
        {
            SqlConnection con = new SqlConnection(connection);
            SqlCommand cmd = new SqlCommand(sql, con);
            int roweffect = -1;

            try
            {
                con.Open();
                roweffect = cmd.ExecuteNonQuery(); // Trả về số dòng bị ảnh hưởng (>0 là thành công)
                con.Close();
            }
            catch (Exception ex)
            {
                con.Close();
                return -1;
            }

            return roweffect;
        }
    
}
}
